require(['core/first'], function() { // jshint ignore:line
    require(['theme_essential/anti_gravity', 'core/log'], function(ag, log) { // jshint ignore:line
        log.debug('Essential JavaScript initialised');
    });
});
