<?php
/**
 * @package    theme_academi
 * @copyright  2015 onwards Nephzat Dev Team (http://www.nephzat.com)
 * @authors    Nephzat Dev Team , nephzat.com
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require_once('renderers/course_renderer.php');
